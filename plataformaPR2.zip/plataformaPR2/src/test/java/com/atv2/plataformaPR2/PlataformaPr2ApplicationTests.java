package com.atv2.plataformaPR2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PlataformaPr2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
