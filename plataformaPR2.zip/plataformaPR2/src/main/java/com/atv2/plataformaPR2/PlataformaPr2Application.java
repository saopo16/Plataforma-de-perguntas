package com.atv2.plataformaPR2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PlataformaPr2Application {

	public static void main(String[] args) {
		SpringApplication.run(PlataformaPr2Application.class, args);
	}

}
