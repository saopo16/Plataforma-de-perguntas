package com.novo.prNovo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PrNovoApplicationTests {

	@Test
	void contextLoads() {
	}

}
